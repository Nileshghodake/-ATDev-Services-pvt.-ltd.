package com.atdev.student.controller;

import com.atdev.student.entity.Student;
import com.atdev.student.model.Response;
import com.atdev.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    StudentService studentService ;


    @GetMapping("/")
    public Response getAllStudents() {
        try {
            List<Student> studentList = studentService.getAllStudents();
            if(studentList == null) {
                return cerateResponse(404,"Students not found", null);
            } else {
                return cerateResponse(200,"Student info fetched",studentList);
            }

        } catch(Exception e) {
            return cerateResponse(500,"Failed to fetch  students",e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public Response getStudentById(@PathVariable("id") Integer id) {
        try {
            Student student = studentService.getStudentById(id);
            if(student == null) {
                return cerateResponse(404,"Student not found", null);
            } else {
                return cerateResponse(200,"Student info fetched",student);
            }

        } catch(Exception e) {
            return cerateResponse(500,"Failed to get student detail",e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public Response deleteStudentById(@PathVariable("id") Integer id) {
        try {
            studentService.deleteStudentById(id);
            return cerateResponse(200,"Student info updated",null);
        } catch(Exception e) {
            return cerateResponse(500,"Failed to delete",e.getMessage());
        }
    }

    @PostMapping("/")
    public Response saveStudent(@RequestBody Student student) {
        try {
            return cerateResponse(200,"Student info added", studentService.saveStudent(student));
        } catch(Exception e) {
            return cerateResponse(500,"Failed to add student detail",e.getMessage());
        }
    }

    @PutMapping("/")
    public Response updateStudent(@RequestBody Student student) {
        try {
            return cerateResponse(200,"Student info updated",studentService.saveStudent(student));
        } catch(Exception e) {
            return cerateResponse(500,"Failed to update",e.getMessage());
        }
    }

    private Response cerateResponse(int id, String code, Object data) {
        return new Response(id, code, data);
    }

}