package com.atdev.student.dao;


import com.atdev.student.entity.Student;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends CrudRepository<Student, Integer> {
    @Override
    List<Student> findAll();

    @Override
    Optional<Student> findById(Integer integer);

    @Override
    void deleteById(Integer integer);

    @Override
    Student save(Student entity);
}
